﻿namespace UcenjeWP4.KonzolnaAplikacija.Model
{
    internal abstract class Entitet
    {
        public int? Sifra { get; set; }

    }
}
